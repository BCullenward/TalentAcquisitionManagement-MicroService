package io.fullstackbasics.talentfullfillmentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalentFullfillmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalentFullfillmentServiceApplication.class, args);
	}

}
