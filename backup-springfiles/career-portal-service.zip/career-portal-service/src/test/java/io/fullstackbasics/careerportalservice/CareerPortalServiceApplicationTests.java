package io.fullstackbasics.careerportalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerPortalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
