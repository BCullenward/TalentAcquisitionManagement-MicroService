package io.fullstackbasics.tamsdiscoveryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TamsDiscoveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TamsDiscoveryServiceApplication.class, args);
	}

}
