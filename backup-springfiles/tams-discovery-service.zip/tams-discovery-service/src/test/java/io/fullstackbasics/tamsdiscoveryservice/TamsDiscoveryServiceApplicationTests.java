package io.fullstackbasics.tamsdiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TamsDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
