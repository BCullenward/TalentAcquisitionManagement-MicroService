package io.fullstackbasics.tamsapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TamsApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TamsApiGatewayApplication.class, args);
	}

}
