package io.fullstackbasics.tamsapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TamsApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
