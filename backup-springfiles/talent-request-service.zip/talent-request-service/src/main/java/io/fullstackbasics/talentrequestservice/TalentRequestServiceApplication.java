package io.fullstackbasics.talentrequestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalentRequestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalentRequestServiceApplication.class, args);
	}

}
