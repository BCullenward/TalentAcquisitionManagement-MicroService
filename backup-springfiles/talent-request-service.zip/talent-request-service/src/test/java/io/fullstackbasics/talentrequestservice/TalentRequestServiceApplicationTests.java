package io.fullstackbasics.talentrequestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalentRequestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
